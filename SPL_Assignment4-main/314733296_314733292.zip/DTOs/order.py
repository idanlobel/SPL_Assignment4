class order:
    def __init__(self,id,location,hat):
        self.id = id;
        self.location = location;
        self.hat = hat;
