class supplier:
    def __init__(self,id,name):
        self.id = id;
        self.name = name;